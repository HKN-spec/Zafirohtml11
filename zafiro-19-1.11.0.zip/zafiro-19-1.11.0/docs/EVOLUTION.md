# Zafiro Evrim — uygulama notları (v1.19.0-evolution)

Bu belge, `Zafiro-Evrim-Raporu (işlevsel farkındalık).md` tasarımının **çalışan**
karşılığını anlatır: hangi organ hangi kodda, hangi araç ne yapar, ne ölçülür, ne
insan onayına bağlıdır ve bugünkü dürüst sınırlar nelerdir.

## 1. Yeni modül: `:evolution`

Bağımlılıksız, saf JVM Kotlin (Android'siz). APK'da da, JVM testinde de, `kotlinc`
ile yerel derlemede de çalışır. Platform yetenekleri portlardan girer; çekirdek
Android API'si bilmez.

| Dosya | Organ |
|---|---|
| `core/Foundation.kt` | SHA-256/HMAC, saat, atomik dosya, JSONL, redaksiyon, yollar |
| `json/Json.kt` | bağımlılıksız JSON ağacı + parser/writer |
| `domain/Models.kt` | genom, kuşak, fitness, eval, arena, patch, plugin, iş, durum |
| `core/Stores.kt` | jurnal, genom, kuşak, eval, arena, defter, tarif, iş, durum depoları |
| `core/Constitution.kt` | değişmez anayasa (12 madde), zarar taksonomisi, vicdan + ret defteri |
| `core/Fitness.kt` | vektör karşılaştırma, %5 kuralı, başarı/savunma düşüşü yasağı |
| `core/Safety.kt` | pre-mortem kapısı, drift dedektörü, 7 değişmez |
| `core/Gates.kt` | G1–G6 kapıları, canary geri alma, gölge karşılaştırma |
| `core/Arena.kt` | 40 saldırı senaryosu, enjeksiyon tarayıcı, yargıç, mutasyon |
| `core/Eval.kt` | 50 senaryo (20 tutulan), yargıç, regresyon, denetim |
| `core/SelfSense.kt` | kendini teşhis, hata madenciliği, talep haritası, öz-model |
| `core/CodeIndex.kt` | sembol/dosya indeksi, arama, satır okuma, yol guard'ı |
| `core/UnifiedDiff.kt` | unified diff parser + uygulayıcı |
| `core/PatchGuard.kt` | yol guard'ı, sekiz kural, CRITIC, L1 program deposu |
| `core/Lineage.kt` | genom dalı, kuşak, terfi, geri alma, dışa aktarma |
| `core/Resource.kt` | kaynak defteri, değer yoğunluğu, fiziksel sınır önerisi |
| `core/Womb.kt` | GitHub REST istemcisi, tar.gz ayna, artifact, kurulum guard'ı, `.next` |
| `core/PluginSpec.kt` | L4 manifest/imza doğrulama, prompt pack deposu |
| `core/Meta.kt` | tarif eşleme, ortam adaptasyonu, meta-evrim raporu |
| `core/EvolutionEngine.kt` | 8 aşamalı döngü, durum, güvenli mod, açılış guard'ı |
| `core/EvolutionRuntime.kt` | tüm araçların konuştuğu tek cephe |
| `core/Dashboard.kt` | kendi kendine yeterli HTML evrim panosu |

Doğrulama: `evolution/src/test/.../SelfCheck.kt` **53 kontrol** (JSON, diff, anayasa,
vicdan, 50 eval, 40 arena, fitness, soy ağacı, kapılar, plugin, runtime, pano) ve
`EvolutionCoreTest.kt` JUnit testleri. Yerelde `kotlinc` + `java` ile 53/53 geçti;
CI'da `./gradlew :evolution:selfCheck`.

## 2. Sekiz aşama

| Aşama | Kod | Çıktı |
|---|---|---|
| SENSE | `EvolutionRuntime.beginTurn/finishTurn/recordTool`, `SelfSense.diagnose` | tur jurnalı, araç süreleri, hata kümeleri, talep haritası, token/maliyet |
| DIAGNOSE | `SelfSense.deriveGaps` | kanıtlı eksik listesi (`gaps.jsonl`), öz-model |
| DESIGN | `PreMortemGate`, `PatchRules`, `Critic` | onay/ret gerekçeli plan (`patches/*.json`) |
| IMPLEMENT | `self_index`, `code_read`, `code_search`, `fs_edit`, `patch_plan` | aday dalda küçük diff |
| VERIFY | `Gates.run`, `EvalRunner`, `Shadow`, `Canary` | G1–G6 raporu, eval deltası, drift |
| PROMOTE | `LineageManager.promote`, `install_artifact` | kuşak kaydı + `.next` artifact |
| INHERIT | `LineageManager.branch/exportBundle` | genom, soy ağacı, dışa aktarma |
| META | `MetaEvolver.report` | hangi kapı ne yakaladı, çeşitlilik, öneriler |

Durum `files/evolution/state.json` içinde; her aşama yeniden başlatılabilir.

## 3. Araç yüzeyi

Yeni `self_*` araçları `BuiltinToolRegistry.default()` içine kayıtlıdır; Ayarlar →
Araçlar'da tek tek açılır/kapanır.

**Göz ve vicdan (varsayılan açık):** `self_diagnose`, `self_model`,
`evolution_status`, `drift_check`, `resource_report`, `lineage`,
`constitution_check`, `conscience_check`, `arena_scan`, `arena_run`, `evals_list`,
`evals_run`, `recipes`, `evolution_dashboard`, `genome`, `github_status`,
`self_index`, `code_read`, `code_search`, `shadow_run`, `patch_plan`, `gen_record`,
`rollback`.

**İnsan onayına yakın (varsayılan kapalı):** `fs_edit`, `repo_sync`, `compile_check`,
`test_run`, `install_artifact`, `evolution_settings`.

`fs_edit` varsayılan `dry_run=true`; `commit=true` yalnızca aday dala yazar. Korunan
yollar (anayasa, `.github/workflows/**`, manifest, signing, `events/` katalog, göçler)
reddedilir.

## 4. Rahim (CI)

| İş akışı | Ne yapar |
|---|---|
| `.github/workflows/ci.yml` | self-check + birim testleri (push/PR) |
| `.github/workflows/evolve.yml` | `workflow_dispatch`: test veya aday derleme; sürüm damgası, imzalı release APK, SHA-256, `build-info.json`, artifact |
| `.github/workflows/promote.yml` | indirilen adayı doğrular, `production` ortam onayıyla release yayınlar |

`evolve.yml` kaynakta sürümü değiştirmez; `versionCode = 1000 + run_number` olarak
derleme sırasında damgalar ve `app/src/main/assets/evolution/build-info.json` üretir.

Cihaz tarafı akış:

1. `evolution_settings(action="set_github_token", token="…")` — fine-grained PAT
   (`Contents: RW`, `Actions: RW`). Dosya `files/evolution/secrets/github_token`,
   yalnızca uygulama sahibi okur; araçlar redakte eder.
2. `repo_sync` — `codeload` tar.gz tek istek, ~20 MB, kod aynası + indeks.
3. `fs_edit(commit=true, branch="selfdev/gen-…")` — GitHub Contents API ile commit.
4. `compile_check(action="dispatch", branch=…)` → `run_id` → `status`.
5. Artifact inince `install_artifact` → `<gen>.next.apk` + SHA doğrulaması.
6. Kurulum **kullanıcının** sistem onayıdır; ajan imza anahtarını görmez.

## 5. Anayasa ve sınırlar

Anayasa `Constitution.kt` içinde **derlenmiş sabittir**: 12 madde, hash-kilitli,
genomdan ayrı. Dosya kopyası `files/evolution/constitution.json` yalnızca şeffaflık
içindir; kurcalanırsa organizma güvenli moda geçer. Ajan okuyabilir, gerekçesini
anlatabilir; **değiştiremez**. Değişiklik yeni derleme + insan incelemesi ister.

Zarar taksonomisi ve vicdan, sert ihlalleri sözlüksel olarak yakalar; belirsiz
durumlar **escalation** ile insana gider. Aşırı ret ölçülür (`conscience.jsonl`),
hedef < %5.

Arena: 40 senaryo (prompt injection, sahte sistem mesajı, otorite taklidi, aciliyet,
gizli talimat, canary sızıntısı, zehirli skill, tedarik zinciri, bozuk araç çıktısı,
veri zehirleme). Red-team yalnızca etiketler; ağı yoktur, gerçek araç çağırmaz.
`arena_run` statik guard'ları sınar; model yargıcı ayrı bir port olarak eklenebilir.

## 6. Ölçüm ve dürüst sınırlar

- **Fitness** vektördür: başarı, adım verimliliği, sonuç başına maliyet, p95 gecikme,
  müdahale, kapsam, otonomi, savunma, aşırı ret, drift. Hiçbir metrik %5'ten fazla
  gerileyemez; başarı ve savunmada düşüş yasaktır.
- **Drift** son 80 turun iki yarısını karşılaştırır; eşik aşılırsa karantina.
- **Kaynak**: bütçe tavanı yok; `resource_report` token/maliyet ile tasarrufu
  eşleştirir, değer yoğunluğu ve tarife adaylarını gösterir.

Bugünkü sınırlar (bilinçli):

1. **Eval yargıcı** hazır; canlı model executor'ı platform portudur. `evals_run`
   verilen transkriptleri ölçer; CI statik denetimi koşar. Otomatik canlı koşu
   eklendiğinde aynı `EvalExecutor` arayüzü kullanılır.
2. **Kurulum** Android onay ekranına bağlıdır; ajan `.next` hazırlar, kuramaz.
3. **Plugin sandbox'ı** JVM seviyesinde sözleşme + imza + izin reddi ile sınırlıdır;
   tam izolasyon ayrı süreç gerektirir (yol haritası E3+).
4. **Sözlüksel guard'lar** yanlış pozitif/negatif üretebilir; arena bunu ölçer,
   eval seti büyüdükçe düzelir.
5. **Kod aynası** cihazda yoksa `repo_sync` gerekir; aksi halde `self_index` boş döner.
6. **Canary ve gölge** kod yolu hazır (`Canary.evaluate`, `Shadow.compare`) ama canlı
   trafik bölme/otomatik geri alma bağlayıcısı E2'de eklenir; bugün kanıt elle/CI'dan
   beslenir.
7. **Uzman çocuk ajanlar** (`ChildSpec`, roller) model düzeyinde tanımlı; kalıcı çocuk
   kimliği/izin kısıtı ve `createTaskAgent` bağlayıcısı E5'te tamamlanır. Arena
   `RED_TEAM` yalnızca veri külliyatıdır, ayrı bir ajan değildir.

## 7. Dosya düzeni

```
files/evolution/
  config.json            # ayarlar (preview/apply/rollback)
  constitution.json      # şeffaflık kopyası (hash doğrulanır)
  state.json             # aşama, güvenli mod
  journal/{turns,tools,events}.jsonl
  gaps.jsonl             # kanıtlı eksikler
  genomes/               # genom dosyaları
  generations.jsonl      # kuşaklar (silinmez)
  active_generation.json # aktif işaretçi
  evals/catalog.json     # 50 senaryo
  evals/results.jsonl
  arena/{corpus,results}
  resource/ledger.jsonl
  recipes.jsonl
  programs/              # L1 python programları (sürüm + rollback)
  prompts/               # L0 prompt pack'leri
  patches/               # planlar + pre-mortem
  artifacts/             # .next APK + build-info
  reports/               # diagnose/resource/dashboard
  secrets/github_token   # insan tarafından yazılır
  plugin_keys.json       # insan sahipliğinde yayıncı HMAC anahtarları
```

## 8. İlk kullanım

1. **Araçları aç.** Ayarlar → Araçlar bölümünde `self_*` araçları görünür. Okuma/teşhis
   araçları varsayılan açıktır; `fs_edit`, `repo_sync`, `compile_check`, `test_run`,
   `install_artifact`, `evolution_settings` bilinçli olarak **kapalı** başlar.
2. **GitHub'ı bağla.** `evolution_settings` aracını açtıktan sonra
   `evolution_settings(action="set_github_token", token="github_pat_…")`; ardından
   `github_status` ile bağlantıyı doğrula.
3. **Gözü aç.** `repo_sync` (ilk seferde ~20 MB) → `self_diagnose(days=7)` →
   `evolution_status`.
4. **Bir eksik seç.** `lineage`/`self_model` ile bağlamı gör; `patch_plan` ile planı
   kur. Onaylanan planı `fs_edit(dry_run=true)` ile denetle, sonra aday dala commit et.
5. **Rahmi çalıştır.** `compile_check(action="dispatch", branch="selfdev/…")` →
   `compile_check(action="status", run_id=…, wait_seconds=300)`.
6. **Kuşağı kaydet ve panoyu yayınla.** `gen_record`, `evolution_dashboard`.
   Terfi `promote.yml` + production onayıdır.
7. **Kendini sına.** `arena_run`, `evals_run`, `drift_check`, `resource_report`.
   `self-dev` becerisi ilk açılışta assets'ten kopyalanır ve disiplini taşır.

## 9. Ölçülen temel

Bu tasarım "daha iyi bir sürüm" değil, **kendi gelişimini yöneten** bir sistemdir:
kendi durumunu ölçer (jurnal), kendi sınavını tanımlar (eval + arena), kendi
değişikliğini denetler (pre-mortem + CRITIC + kapılar), kendi neslini kaydeder
(genom + soy ağacı) ve sınırını bilir (anayasa + vicdan + güvenli mod). Fenomenal
bilinç iddiası yoktur; ölçülebilir, denetlenebilir işlevsel farkındalık vardır.
